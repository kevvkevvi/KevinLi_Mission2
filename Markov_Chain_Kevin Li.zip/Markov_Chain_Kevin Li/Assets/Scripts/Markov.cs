﻿/*Kevin Li
 * CSCI 3725: Computational Creativity
 * Mission 2: A Markov Distribution
 * 
 * Markov.cs is a component of my player in Unity. It initializes an animator and
 * updates the state of the player based off a Markov Chain of order 1 every 3 seconds.
 * In this mission, my player initially starts in a standing state. Using a random float
 * generator, my player can potentially transition to one of 4 states: sleep, wake up,
 * stand up, or drink. The conditional probabilities are listed inside the class
 * MarkovMatrix for clarification.
 * 
 */


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MarkovMatrix
{
    //create a 4x4 matrix containing a Markov Chain, with the probability 
    //format being "row given column". The entries in the rows and columns
    //are in the order of: Sleep, Wake Up, Stand Up, and Drink.
    public static Matrix4x4 matrix()
    {
        float sleep_sleep = 0.5F;
        float wake_sleep = 0.5F;
        float stand_sleep = 0.0F;
        float drink_sleep = 0.0F;
        float sleep_wake = 0.3F;
        float wake_wake = 0.0F;
        float stand_wake = 0.4F;
        float drink_wake = 0.3F;
        float sleep_stand = 0.4F;
        float wake_stand = 0.0F;
        float stand_stand = 0.0F;
        float drink_stand = 0.6F;
        float sleep_drink = 0.3F;
        float wake_drink = 0.0F;
        float stand_drink = 0.0F;
        float drink_drink = 0.7F;
        //initializes a new 4x4 Matrix
        Matrix4x4 markov = new Matrix4x4();
        markov[0, 0] = sleep_sleep;
        markov[0, 1] = wake_sleep;
        markov[0, 2] = stand_sleep;
        markov[0, 3] = drink_sleep;
        markov[1, 0] = sleep_wake;
        markov[1, 1] = wake_wake;
        markov[1, 2] = stand_wake;
        markov[1, 3] = drink_wake;
        markov[2, 0] = sleep_stand;
        markov[2, 1] = wake_stand;
        markov[2, 2] = stand_stand;
        markov[2, 3] = drink_stand;
        markov[3, 0] = sleep_drink;
        markov[3, 1] = wake_drink;
        markov[3, 2] = stand_drink;
        markov[3, 3] = drink_drink;
        //returns the 4x4 Matrix initialized with the conditional probabilities
        //of the states
        return markov;
    }
}
//My player in Unity has Markov.cs as a component, and the Markov class directly
//determines what my player does when I run the Unity progrmam.
public class Markov : MonoBehaviour
{
    //calling an instance of the matrix in MarkovMatrix
    static Matrix4x4 matrix = MarkovMatrix.matrix();
    //initializing an animator to obtain animation states and
    //make changes to animation states
    private Animator animator;
    //timer to restrict Update() from updating on every frame
    private float timer = 0.0F;
    //wait time is 3 seconds for an update
    private float wait = 3.0F;


    // Start is called before the first frame update
    void Start()
    {
        //initializes the animator
        animator = GetComponent<Animator>();
        //sets the animator's "isStanding" state to true
        animator.SetBool("isStanding", true);
        //Displays in console that Markov.cs has started
        Debug.Log("started");
    }

    //updates the program every frame
    void Update()
    {
        //starts the timer
        timer += Time.deltaTime;
        //once the timer exceeds the wait time, update the program
        if (timer > wait)
        {
            //randomly getting a probability between 0.0f and 1.0f
            float prob = Random.Range(0.0F, 1.0F);
            //if the current state of the animation is "Sleep"
            if (animator.GetCurrentAnimatorStateInfo(0).IsName("Sleep"))
            {
                //displays "Sleeping" in the console
                Debug.Log("sleeping");
                //set the parameter "isSleeping" to true
                animator.SetBool("isSleeping", true);
                //if the next state determined by the random prob is sleep
                if (prob < 0.5F)
                {
                    //set "goSleeping" to true, everything else to false
                    animator.SetBool("isWaking", false);
                    animator.SetBool("isStanding", false);
                    animator.SetBool("isDrinking", false);
                    animator.SetBool("goSleeping", true);
                    animator.SetBool("goWaking", false);
                    animator.SetBool("goStanding", false);
                    animator.SetBool("goDrinking", false);
                }
                /*
                 * Everything below is done
                 * under the same format as
                 * the former example
                 * 
                 * 
                 * 
                 */
                else
                {
                    animator.SetBool("isWaking", false);
                    animator.SetBool("isStanding", false);
                    animator.SetBool("isDrinking", false);
                    animator.SetBool("goSleeping", false);
                    animator.SetBool("goWaking", true);
                    animator.SetBool("goStanding", false);
                    animator.SetBool("goDrinking", false);
                }
            }
            if (animator.GetCurrentAnimatorStateInfo(0).IsName("Wake"))
            {
                Debug.Log("waking");
                animator.SetBool("isWaking", true);
                if (prob < 0.3F)
                {
                    animator.SetBool("isSleeping", false);
                    animator.SetBool("isStanding", false);
                    animator.SetBool("isDrinking", false);
                    animator.SetBool("goSleeping", true);
                    animator.SetBool("goWaking", false);
                    animator.SetBool("goStanding", false);
                    animator.SetBool("goDrinking", false);
                }
                if (prob >= 0.3F && prob < 0.7F)
                {
                    animator.SetBool("isSleeping", false);
                    animator.SetBool("isStanding", false);
                    animator.SetBool("isDrinking", false);
                    animator.SetBool("goSleeping", false);
                    animator.SetBool("goWaking", false);
                    animator.SetBool("goStanding", true);
                    animator.SetBool("goDrinking", false);
                }
                else
                {
                    animator.SetBool("isSleeping", false);
                    animator.SetBool("isStanding", false);
                    animator.SetBool("isDrinking", false);
                    animator.SetBool("goSleeping", false);
                    animator.SetBool("goWaking", false);
                    animator.SetBool("goStanding", false);
                    animator.SetBool("goDrinking", true);
                }

            }
            if (animator.GetCurrentAnimatorStateInfo(0).IsName("Stand"))
            {
                Debug.Log("standing");
                animator.SetBool("isStanding", true);
                if (prob < 0.4F)
                {
                    animator.SetBool("isSleeping", false);
                    animator.SetBool("isWaking", false);
                    animator.SetBool("isDrinking", false);
                    animator.SetBool("goSleeping", true);
                    animator.SetBool("goWaking", false);
                    animator.SetBool("goStanding", false);
                    animator.SetBool("goDrinking", false);
                }
                else
                {
                    animator.SetBool("isSleeping", false);
                    animator.SetBool("isWaking", false);
                    animator.SetBool("isDrinking", false);
                    animator.SetBool("goSleeping", false);
                    animator.SetBool("goWaking", false);
                    animator.SetBool("goStanding", false);
                    animator.SetBool("goDrinking", true);
                }

            }
            if (animator.GetCurrentAnimatorStateInfo(0).IsName("Drink"))
            {
                Debug.Log("drinking");
                animator.SetBool("isDrinking", true);
                if (prob < 0.3F)
                {
                    animator.SetBool("isSleeping", false);
                    animator.SetBool("isWaking", false);
                    animator.SetBool("isStanding", false);
                    animator.SetBool("goSleeping", true);
                    animator.SetBool("goWaking", false);
                    animator.SetBool("goStanding", false);
                    animator.SetBool("goDrinking", false);
                }
                else
                {
                    animator.SetBool("isSleeping", false);
                    animator.SetBool("isWaking", false);
                    animator.SetBool("isStanding", false);
                    animator.SetBool("goSleeping", false);
                    animator.SetBool("goWaking", false);
                    animator.SetBool("goStanding", false);
                    animator.SetBool("goDrinking", true);
                }

            }

            //reset the timer
            timer -= wait;


        }
        
    }

}
